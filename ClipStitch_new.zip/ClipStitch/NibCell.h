//
//  NibCell.h
//  ClipStitch
//
//  Created by iApp on 08/10/15.
//  Copyright (c) 2015 iApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NibCell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *filterImageView;

@end
