//
//  CollectionViewController.h
//  ClipStitch
//
//  Created by iApp on 08/10/15.
//  Copyright (c) 2015 iApp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NibCell.h"
#import "AppDelegate.h"

@interface CollectionViewController : UIViewController<UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>



@end
