//
//  NibCell.m
//  ClipStitch
//
//  Created by iApp on 08/10/15.
//  Copyright (c) 2015 iApp. All rights reserved.
//

#import "NibCell.h"

@implementation NibCell

@end
